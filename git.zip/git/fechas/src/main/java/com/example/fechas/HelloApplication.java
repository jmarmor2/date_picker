package com.example.fechas;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.layout.TilePane;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;

public class HelloApplication extends Application {
    @Override
    public void start(Stage s) {

        s.setTitle("creating date picker");


        TilePane r = new TilePane();


        Label l = new Label("no date selected");


        DatePicker d = new DatePicker();


        EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e) {
                // get the date picker value
                LocalDate i = d.getValue();

                // get the selected date
                l.setText("Date :" + i);
            }
        };


        d.setShowWeekNumbers(true);


        d.setOnAction(event);


        r.getChildren().add(d);
        r.getChildren().add(l);

        // create a scene
        Scene sc = new Scene(r, 200, 200);

        // set the scene
        s.setScene(sc);

        s.show();
    }

    public static void main(String args[]) {
        // launch the application
        launch(args);
    }
}