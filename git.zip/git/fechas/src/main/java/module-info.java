module com.example.fechas {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.fechas to javafx.fxml;
    exports com.example.fechas;
}